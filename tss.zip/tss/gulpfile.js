var gulp = require('gulp'),
    ts = require('gulp-typescript'),
    minifycss = require('gulp-minify-css'),
    concat = require('gulp-concat'),
    rename = require('gulp-rename'),
    uglify = require('gulp-uglify'),
    del = require('del');

var tsProject = ts.createProject('tsconfig.json');
var root = {
    'npmroot': 'node_modules/'
}

var paths = {
      '@angular/core': root.npmroot+'@angular/core/bundles/core.umd.js',
      '@angular/common': root.npmroot+'@angular/common/bundles/common.umd.js',
      '@angular/compiler': root.npmroot+'@angular/compiler/bundles/compiler.umd.js',
      '@angular/platform-browser': root.npmroot+'@angular/platform-browser/bundles/platform-browser.umd.js',
      '@angular/platform-browser-dynamic': root.npmroot+'@angular/platform-browser-dynamic/bundles/platform-browser-dynamic.umd.js',
      '@angular/http': root.npmroot+'@angular/http/bundles/http.umd.js',
      '@angular/router': root.npmroot+'@angular/router/bundles/router.umd.js',
      '@angular/router/upgrade': root.npmroot+'@angular/router/bundles/router-upgrade.umd.js',
      '@angular/forms': root.npmroot+'@angular/forms/bundles/forms.umd.js',
      '@angular/upgrade': root.npmroot+'@angular/upgrade/bundles/upgrade.umd.js',
      '@angular/upgrade/static': root.npmroot+'@angular/upgrade/bundles/upgrade-static.umd.js',
      //'rxjs':                      root.npmroot+'rxjs',
      'angular-in-memory-web-api': root.npmroot+'angular-in-memory-web-api/bundles/in-memory-web-api.umd.js'

}



gulp.task('combine', ['minifyjs'], function() {
    gulp.src('build/js/*.js').pipe(concat('main.js')).pipe(gulp.dest('build/js'));
    gulp.src('dist/js/*.js').pipe(concat('main.min.js')).pipe(gulp.dest('dist/js'));
})
  

gulp.task('minifyjs', ['build'], function() {
    return gulp.src('build/js/*.js')
        .pipe(rename({suffix:'.min'}))
        .pipe(uglify())
        .pipe(gulp.dest('dist/js'));  //输出
});


gulp.task('build', function() {
     return gulp.src('src/ts/*.ts')
        .pipe(tsProject())
        .pipe(gulp.dest('build/js'));          
});


gulp.task('clean', function(){
    del(['dist/js/*.js'],{force: true});
    del(['build/js/*.js'],{force: true});
    del(['libs/*.js'],{force: true});
    del(['libs/rxjs/*.js'],{force: true});
 });        //清除dist中所有的文件和文件夹，适合新的项目开始时使用


gulp.task('cplibs', function(){
     for (path in paths) {
          gulp.src(paths[path]).pipe(gulp.dest("libs"))
     }
     
    gulp.src([root.npmroot+'rxjs/*.js', root.npmroot+'rxjs/*.map']).pipe(gulp.dest("libs/rxjs"));
    gulp.src([root.npmroot+'rxjs/util/*.js', root.npmroot+'rxjs/util/*.map']).pipe(gulp.dest("libs/rxjs/util"));
    gulp.src([root.npmroot+'rxjs/symbol/*.js', root.npmroot+'rxjs/symbol/*.map']).pipe(gulp.dest("libs/rxjs/symbol"));
    gulp.src(["node_modules/.2.4.1@core-js/client/shim.min.js", "node_modules/.2.4.1@core-js/client/shim.min.js.map"]).pipe(gulp.dest("libs/polyfills"));
    gulp.src(["node_modules/.0.6.26@zone.js/dist/zone.js", "node_modules/.0.6.26@zone.js/dist/zone.map"]).pipe(gulp.dest("libs/polyfills"));
    gulp.src(["node_modules/.0.1.8@reflect-metadata/Reflect.js", "node_modules/.0.1.8@reflect-metadata/Reflect.js.map"]).pipe(gulp.dest("libs/polyfills"));
    gulp.src(["node_modules/.0.19.40@systemjs/dist/system.src.js", "node_modules/.0.19.40@systemjs/dist/system.src.map"]).pipe(gulp.dest("libs/polyfills"));

 });        //清除dist中所有的文件和文件夹，适合新的项目开始时使用

 



gulp.task('default', ['clean'], function() {
    gulp.start('build','minifyjs','combine','cplibs');
})