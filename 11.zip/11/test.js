var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
function testde(target) {
    target.abc = 'shit';
    console.log(target);
}
var abb = (function () {
    function abb() {
    }
    abb.prototype.prit = function () {
        console.log(this.ava);
    };
    abb = __decorate([
        testde, 
        __metadata('design:paramtypes', [])
    ], abb);
    return abb;
}());
var x = new abb();
x.ava = "ksks";
console.log(x);
// class Route {
// greeting: string;
// constructor(greet: string){
// this.greeting = greet;
// }
// @route("hello")
// default(): any {
// console.log(this.greeting);
// }
// }
// function route(name: string) {
// console.log(name);
// return function (target: Object, value: string, desc: PropertyDescriptor) {
// console.log(name,'>>>>');
// }
// }
// let xx = new Route("shit");
// xx.default(); 
//# sourceMappingURL=test.js.map