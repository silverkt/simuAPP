function testde(target: any) {
     
        target.abc = 'shit'; 
        console.log(target);
     
}

@testde
class abb {
    
    ava : string;
    
    prit() {
        console.log(this.ava);
    }
} 
 

let x = new abb();
x.ava = "ksks";
console.log(x);
 

// class Route {
// greeting: string;
// constructor(greet: string){
// this.greeting = greet;
// }
// @route("hello")
// default(): any {
// console.log(this.greeting);
// }
// }
// function route(name: string) {
// console.log(name);
// return function (target: Object, value: string, desc: PropertyDescriptor) {
// console.log(name,'>>>>');
// }
// }

// let xx = new Route("shit");
// xx.default();